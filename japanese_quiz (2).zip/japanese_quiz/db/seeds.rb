Word.destroy_all

words = [
  # ---- 1그룹 ----
  { group: 1, pos: "v", japanese: "飽きる",  reading_breakdown: "飽(a/ki)る(ru)",       romaji: "akiru",      korean_meaning: "싫증 나다, 물리다" },
  { group: 1, pos: "v", japanese: "余る",    reading_breakdown: "余(a/ma)る(ru)",       romaji: "amaru",      korean_meaning: "남다, 남아돌다" },
  { group: 1, pos: "v", japanese: "当たる",  reading_breakdown: "当(a/ta)る(ru)",       romaji: "ataru",      korean_meaning: "맞다, 명중하다" },
  { group: 1, pos: "v", japanese: "預ける",  reading_breakdown: "預(a/zu)け(ke)る(ru)", romaji: "azukeru",    korean_meaning: "맡기다" },
  { group: 1, pos: "v", japanese: "編む",    reading_breakdown: "編(a)む(mu)",          romaji: "amu",        korean_meaning: "짜다, 뜨개질하다" },
  { group: 1, pos: "v", japanese: "表す",    reading_breakdown: "表(a/ra/wa)す(su)",    romaji: "arawasu",    korean_meaning: "나타내다, 표현하다" },

  # ---- 2그룹 ----
  { group: 2, pos: "v",   japanese: "開発する", reading_breakdown: "開(ka/i)発(ha/tsu)す(su)る(ru)", romaji: "kaihatsuru", korean_meaning: "개발하다" },
  { group: 2, pos: "adj", japanese: "有名な",   reading_breakdown: "有(yu/u)名(me/i)な(na)",         romaji: "yuumeina",   korean_meaning: "유명한" },
  { group: 2, pos: "n",   japanese: "会社",     reading_breakdown: "会(ka/i)社(sha)",                romaji: "kaisha",     korean_meaning: "회사" },
  { group: 2, pos: "n",   japanese: "今年",     reading_breakdown: "今(ko)年(to/shi)",               romaji: "kotoshi",    korean_meaning: "올해" },
  { group: 2, pos: "n",   japanese: "現代文学", reading_breakdown: "現(gen)代(da/i)文(bun)学(ga/ku)", romaji: "gendaibungaku", korean_meaning: "현대문학" },
  { group: 2, pos: "n",   japanese: "エンジニアチーム", reading_breakdown: "エ(e)ン(n)ジ(ji)ニ(ni)ア(a)チ(chi)ー(i)ム(mu)", romaji: "enjiniachiimu", korean_meaning: "엔지니어 팀" },

  # ---- 3그룹 ----
  { group: 3, pos: "n", japanese: "携帯電話", reading_breakdown: "携(ke/i)帯(ta/i)電(den)話(wa)", romaji: "keitaidenwa", korean_meaning: "휴대전화" },
  { group: 3, pos: "v", japanese: "通話する", reading_breakdown: "通(tsu/u)話(wa)す(su)る(ru)",   romaji: "tsuuwasuru",  korean_meaning: "통화하다" },
  { group: 3, pos: "n", japanese: "自己紹介", reading_breakdown: "自(ji)己(ko)紹(sho/u)介(ka/i)", romaji: "jikoshookai", korean_meaning: "자기소개" },
  { group: 3, pos: "n", japanese: "家庭",     reading_breakdown: "家(ka)庭(te/i)",                romaji: "katei",       korean_meaning: "가정" },
  { group: 3, pos: "n", japanese: "部下",     reading_breakdown: "部(bu)下(ka)",                  romaji: "buka",        korean_meaning: "부하, 부하 직원" },
  { group: 3, pos: "n", japanese: "上司",     reading_breakdown: "上(jo/u)司(shi)",               romaji: "jooshi",      korean_meaning: "상사, 직장 상사" },

  # ---- 4그룹 ----
  { group: 4, pos: "n",   japanese: "環境",     reading_breakdown: "環(kan)境(kyo/u)", romaji: "kankyou", korean_meaning: "환경" },
  { group: 4, pos: "n",   japanese: "効率",     reading_breakdown: "効(ko/u)率(ri/tsu)", romaji: "kooritsu", korean_meaning: "효율" },
  { group: 4, pos: "n",   japanese: "有効",     reading_breakdown: "有(yu/u)効(ko/u)", romaji: "yuukou", korean_meaning: "유효" },
  { group: 4, pos: "v",   japanese: "詰める",   reading_breakdown: "詰(tsu)め(me)る(ru)", romaji: "tsumeru", korean_meaning: "채우다, 좁히다" },
  { group: 4, pos: "n/v", japanese: "蓄積",     reading_breakdown: "蓄(chi/ku)積(se/ki)", romaji: "chikuseki", korean_meaning: "축적" },
  { group: 4, pos: "n",   japanese: "年齢",     reading_breakdown: "年(nen)齢(re/i)", romaji: "nenrei", korean_meaning: "연령, 나이" },
  { group: 4, pos: "n",   japanese: "プログラミング言語", reading_breakdown: "プ(pu)ロ(ro)グ(gu)ラ(ra)ミ(mi)ン(n)グ(gu)言(gen)語(go)", romaji: "puroguramingogengo", korean_meaning: "프로그래밍 언어" },
  { group: 4, pos: "n",   japanese: "アーキテクチャ", reading_breakdown: "ア(a)ー(a)キ(ki)テ(te)ク(ku)チ(chi)ャ(ya)", romaji: "aakitekucha", korean_meaning: "아키텍처" },
  { group: 4, pos: "n",   japanese: "監視ツール", reading_breakdown: "監(kan)視(shi)ツ(tsu)ー(u)ル(ru)", romaji: "kanshitsuuru", korean_meaning: "모니터링 툴, 감시 툴" },
  { group: 4, pos: "n",   japanese: "言語",     reading_breakdown: "言(gen)語(go)", romaji: "gengo", korean_meaning: "언어" },
  { group: 4, pos: "n",   japanese: "日本語",   reading_breakdown: "日(ni)本(hon)語(go)", romaji: "nihongo", korean_meaning: "일본어" },
  { group: 4, pos: "n",   japanese: "韓国語",   reading_breakdown: "韓(kan)国(ko/ku)語(go)", romaji: "kankokugo", korean_meaning: "한국어" },
  { group: 4, pos: "n/v", japanese: "打ち合わせ", reading_breakdown: "打(u)ち(chi)合(a)わ(wa)せ(se)", romaji: "uchiawase", korean_meaning: "사전 회의, 미팅" },
  { group: 4, pos: "n/v", japanese: "待ち合わせ", reading_breakdown: "待(ma)ち(chi)合(a)わ(wa)せ(se)", romaji: "machiawase", korean_meaning: "약속하고 만나기" },
  { group: 4, pos: "n/v", japanese: "すり合わせ", reading_breakdown: "す(su)り(ri)合(a)わ(wa)せ(se)", romaji: "suriawase", korean_meaning: "조율, 의견 맞추기" },
  { group: 4, pos: "n",   japanese: "ミーティング", reading_breakdown: "ミ(mi)ー(i)テ(ti)ィ(i)ン(n)グ(gu)", romaji: "miitingu", korean_meaning: "미팅, 회의" },
  { group: 4, pos: "n/v", japanese: "連絡",     reading_breakdown: "連(ren)絡(ra/ku)", romaji: "renraku", korean_meaning: "연락" },
  { group: 4, pos: "n",   japanese: "部屋",     reading_breakdown: "部(he)屋(ya)", romaji: "heya", korean_meaning: "방" },
  { group: 4, pos: "n/v", japanese: "感謝",     reading_breakdown: "感(kan)謝(sha)", romaji: "kansha", korean_meaning: "감사" },
  { group: 4, pos: "n/v", japanese: "謝罪",     reading_breakdown: "謝(sha)罪(za/i)", romaji: "shazai", korean_meaning: "사죄, 사과" },
  { group: 4, pos: "n",   japanese: "パソコン", reading_breakdown: "パ(pa)ソ(so)コ(ko)ン(n)", romaji: "pasokon", korean_meaning: "개인 컴퓨터, PC" },
  { group: 4, pos: "n/v", japanese: "作成",     reading_breakdown: "作(sa/ku)成(se/i)", romaji: "sakusei", korean_meaning: "작성, 제작" },
  { group: 4, pos: "n/v", japanese: "更新",     reading_breakdown: "更(ko/u)新(shin)", romaji: "koushin", korean_meaning: "갱신, 업데이트" },
  { group: 4, pos: "n/v", japanese: "削除",     reading_breakdown: "削(sa/ku)除(jo)", romaji: "sakujo", korean_meaning: "삭제" },
  { group: 4, pos: "n/v", japanese: "上達",     reading_breakdown: "上(jo/u)達(ta/tsu)", romaji: "joodatsu", korean_meaning: "실력이 늚, 향상" },
  { group: 4, pos: "adj", japanese: "下手",     reading_breakdown: "下(he)手(ta)", romaji: "heta", korean_meaning: "서투름, 못함" },
  { group: 4, pos: "n",   japanese: "経験",     reading_breakdown: "経(ke/i)験(ken)", romaji: "keiken", korean_meaning: "경험" },
  { group: 4, pos: "n",   japanese: "経路",     reading_breakdown: "経(ke/i)路(ro)", romaji: "keiro", korean_meaning: "경로" },
  { group: 4, pos: "n",   japanese: "お水",     reading_breakdown: "お(o)水(mi/zu)", romaji: "omizu", korean_meaning: "물" },
  { group: 4, pos: "n",   japanese: "お冷",     reading_breakdown: "お(o)冷(hi/ya)", romaji: "ohiya", korean_meaning: "찬물" },
]

words.each { |w| Word.create!(w) }

puts "Seeded #{Word.count} words."
