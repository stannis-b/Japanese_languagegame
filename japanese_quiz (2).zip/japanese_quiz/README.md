# 일본어 단어 퀴즈 (Japanese Word Quiz)

A tiny Rails app: it shows a Japanese word, you type its **romaji reading**
and its **Korean meaning**, and it tells you if you're right — tracking a
running score in the session. 44 words from your 1〜4그룹 list are pre-seeded.

## Requirements
- Ruby 3.1+
- Bundler (`gem install bundler`)

## Setup

```bash
cd japanese_quiz
bin/setup
```

This installs gems, creates the sqlite3 DB, runs the migration, and seeds
all the words.

If `bin/setup` isn't executable on your machine, run the steps manually:

```bash
bundle install
bin/rails db:create db:migrate db:seed
```

## Run

```bash
bin/rails server
```

Then open http://localhost:3000

## How it works

- `GET /` (`QuizController#index`) picks a random word you haven't seen
  yet in this round (tracked in the session), and shows a form for the
  romaji reading + Korean meaning.
- `POST /quiz/check` compares your input against the word's `romaji` and
  `korean_meaning` (case/space-insensitive; the Korean field accepts any
  one of several comma-separated valid answers, e.g. "싫증 나다, 물리다"
  accepts either "싫증 나다" or "물리다").
- A "그룹 선택" dropdown lets you restrict the quiz to just 1/2/3/4그룹 or
  all words.
- "힌트" (hint) is collapsible and shows the reading breakdown
  (e.g. `飽(a/ki)る(ru)`).
- "점수 초기화" resets your score and reshuffles.

## Adding more words

Edit `db/seeds.rb` and re-run:

```bash
bin/rails db:seed
```

(this clears and re-seeds the `words` table — see `Word.destroy_all` at
the top of the file).
